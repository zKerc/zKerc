import 'package:flutter/material.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Galeria de Imagens',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: const GalleryScreen(),
    );
  }
}

class GalleryScreen extends StatelessWidget {
  const GalleryScreen({Key? key}) : super(key: key);

  static const List<String> imageAssets = [
    'assets/imagem1.jpg',
    'assets/imagem2.jpg',
    'assets/imagem3.jpg',
    'assets/imagem4.jpg',
    'assets/imagem5.jpg',
    'assets/imagem6.jpg',
    'assets/imagem7.jpg',
    'assets/imagem8.jpg',
    'assets/imagem9.jpg',
    'assets/imagem10.jpg',
    'assets/imagem11.jpg',
    'assets/imagem12.jpg',
    'assets/imagem13.jpg',
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Minha Galeria de Imagens'),
      ),
      body: const ImageGallery(),
    );
  }
}

class ImageGallery extends StatelessWidget {
  const ImageGallery({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return GridView.builder(
      gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: 2,
        crossAxisSpacing: 16.0,
        mainAxisSpacing: 16.0,
      ),
      itemCount: GalleryScreen.imageAssets.length,
      itemBuilder: (context, index) {
        return GestureDetector(
          onTap: () {
            _showImageFullScreen(context, GalleryScreen.imageAssets[index]);
          },
          child: Card(
            elevation: 4.0,
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(16.0),
            ),
            child: ClipRRect(
              borderRadius: BorderRadius.circular(16.0),
              child: Center(
                child: Image.asset(
                  GalleryScreen.imageAssets[index],
                  fit: BoxFit.contain, // Mantém o aspecto original
                  width: double.infinity,
                  height: double.infinity,
                ),
              ),
            ),
          ),
        );
      },
    );
  }

  void _showImageFullScreen(BuildContext context, String imagePath) {
    Navigator.of(context).push(MaterialPageRoute<void>(
      builder: (BuildContext context) {
        return Scaffold(
          appBar: AppBar(
            title: const Text('Imagem em Tela Cheia'),
          ),
          body: Center(
            child: Image.asset(imagePath),
          ),
        );
      },
    ));
  }
}
